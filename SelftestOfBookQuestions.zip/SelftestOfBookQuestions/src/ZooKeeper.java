public class ZooKeeper {
    public static void main(String[] args) {
        new ZooKeeper().go();
    }
    void go(){
        Mammal m = new Zebra();
        System.out.println(m.name + m.makeNoise());//Polymorphism is only for instance methods
       // Zebra z = new Zebra();
       // System.out.println(z.name1);
    }
}
class Mammal{
 String name = "furry";
 String makeNoise(){
     return "generic noise";
 }
}
class Zebra extends Mammal{
 String name1 = "Stripes";
 String makeNoise(){
     return "bray";
 }
}