public class X {
    void do1(){
        System.out.println("do1");
    }
}

class Y extends X{
    void do2(){
        System.out.println("do2");
    }
}
class Chrome{
    public static void main(String[] args) {
        X X1 = new X();
        X X2 = new X();
        Y Y1 = new Y();
        X2.do1();
       // (Y)X2.do1(); cannot cast
       ((Y)X2).do2();

    }
}