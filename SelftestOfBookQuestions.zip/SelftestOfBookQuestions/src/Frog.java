public class Frog extends Frob{
    //@Override
   // public void twiddle(String s) {
      // System.out.println("This is a twiddle");
  //  }

   // void frog(){
      //  System.out.println("Frog jumps");
   // }


    @Override
    public void twiddle(Integer i) {
        super.twiddle(i);
    }
}
