public class Bottom2 extends Top {

   // public Bottom2(String s){
      //  System.out.println("D");
  //  }
}
