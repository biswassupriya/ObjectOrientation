public abstract class Frob  implements Frobnicate{
    public void twiddle(Integer i){
        System.out.println("This is an overloading method:" + 1);
    }

    @Override
    public void twiddle(String s) {
        System.out.println("I am a String");
    }
}


