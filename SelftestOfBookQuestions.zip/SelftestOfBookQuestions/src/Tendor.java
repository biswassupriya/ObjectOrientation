public class Tendor extends Singer {
    public static String sing(){
        return "fa";
    }
    public static void main(String[] args) {
        System.out.println("Polymorphism does not apply to the static method");
      Tendor t = new Tendor();
      Singer s = new Singer();
        System.out.println(t.sing() + " " + s.sing());
    }
}
class Singer{
public static String sing(){
    return "la";
}
}