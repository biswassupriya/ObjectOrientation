public class AgedP {
    int x;

    AgedP(){
    }
     public AgedP(int x) {
      //  x = 10;
    }

   // public int age(int x) {
       // x = 10;
      //  return x;
  //  }
   // public void name(){
     //   System.out.println("A Girl");
   // }
}

class Kinder extends AgedP{
   public Kinder(int X){
       super();
      // System.out.println("20");
   }
}

class Myclass {
    public static void main(String[] args) {
        //new AgedP().age(1);
        // System.out.println(new AgedP().age(10));
        //Kinder k =new Kinder(20);
    }
}
