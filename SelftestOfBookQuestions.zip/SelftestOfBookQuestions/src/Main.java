public class Main {
        public static void main(String[]args){
            Frob f = new Frog();
            f.twiddle("sting");
           // System.out.println("This is an string");
            f.twiddle(2);

           //new Bottom2("C");
            System.out.println("C");

        }
    }

