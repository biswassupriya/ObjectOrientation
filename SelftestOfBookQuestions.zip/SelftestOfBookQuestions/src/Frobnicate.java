public interface Frobnicate {
    public void twiddle(String s);
}
